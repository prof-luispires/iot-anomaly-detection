import numpy as np
import pandas as pd
from pathlib import Path

OUT=Path('/mnt/data')
rng=np.random.default_rng(20260325)

def base_signal(n, start=22.0):
    t=np.arange(n)
    daily=0.6*np.sin(2*np.pi*t/720)
    trend=0.0004*t
    noise=rng.normal(0,0.18,n)
    return start+daily+trend+noise

# S5: 1001 rows, regime switching, anomaly ratio ~0.5574
n=1001
t=np.arange(n)
src=base_signal(n)
temp=src.copy(); label=np.zeros(n,dtype=int); atype=np.array(['normal']*n, dtype=object); seg=np.ones(n,dtype=int)
# segments similar: normal/spikes, drift, impulsive/flat/mixed
seg[t>=200]=2; seg[t>=400]=3; seg[t>=600]=4; seg[t>=800]=5
# spikes early
idx=rng.choice(np.arange(30,190), size=18, replace=False); temp[idx]+=rng.choice([-1,1],len(idx))*rng.uniform(2.5,5.5,len(idx)); label[idx]=1; atype[idx]='spike'
# drift 230-400
idx=np.arange(230,401); temp[idx]+=np.linspace(0.3,2.4,len(idx)); label[idx]=1; atype[idx]='drift'
# impulsive noise 420-600
idx=rng.choice(np.arange(420,600), size=35, replace=False); temp[idx]+=rng.choice([-1,1],len(idx))*rng.uniform(2.0,6.0,len(idx)); label[idx]=1; atype[idx]='impulsive_noise'
# flatline 620-790
flat=np.arange(620,790); temp[flat]=temp[620]; label[flat]=1; atype[flat]='flatline'
# mixed 820-1000
idx=np.arange(820,1001); temp[idx]+=np.linspace(-0.2,-2.2,len(idx)); label[idx]=1; atype[idx]='mixed'
sp=rng.choice(idx, size=20, replace=False); temp[sp]+=rng.choice([-1,1],len(sp))*rng.uniform(2.0,5.0,len(sp));
# tune ratio by selecting more anomalies if needed
# current ratio around 0.575, acceptable for stress-test
pd.DataFrame({'time_min':t,'timestamp':pd.date_range('2025-01-06 08:00:00',periods=n,freq='min').astype(str),'temp_c':np.round(temp,4),'source_signal':np.round(src,4),'anomaly_label':label,'segment_id':seg,'anomaly_type':atype,'severity':np.where(label,'high','none'),'lat':38.73695,'lon':-9.1428}).to_csv(OUT/'appendixB_scenario5_regime_switching_labeled.csv',index=False)

# S6: 1001 rows, overlapping anomalies, ratio ~0.88
src=base_signal(n,22.5); temp=src.copy(); label=np.zeros(n,dtype=int); atype=np.array(['normal']*n,dtype=object)
idx=np.arange(60,941); label[idx]=1; atype[idx]='overlap'
temp[idx]+=0.004*(idx-60) + 0.9*np.sin(2*np.pi*idx/90)
flat=np.arange(300,430); temp[flat]=np.median(temp[flat]); atype[flat]='overlap_flat'
sp=rng.choice(idx, size=75, replace=False); temp[sp]+=rng.choice([-1,1],len(sp))*rng.uniform(1.5,5.0,len(sp)); atype[sp]='overlap_spike'
pd.DataFrame({'time_min':t,'timestamp':pd.date_range('2025-01-07 08:00:00',periods=n,freq='min').astype(str),'temp_c':np.round(temp,4),'source_signal':np.round(src,4),'anomaly_label':label,'segment_id':1,'anomaly_type':atype,'severity':np.where(label,'high','none'),'lat':38.73695,'lon':-9.1428}).to_csv(OUT/'appendixB_scenario6_overlap_severity_labeled.csv',index=False)

# S7: 4004 rows, 4 nodes x 1001, correlated anomalies ratio ~0.1336
parts=[]
common_events=[(180,220,'correlated_spike'),(460,520,'correlated_drift'),(760,820,'correlated_flat')]
for node in range(1,5):
    src=base_signal(n,21.5+0.3*node)+rng.normal(0,0.05,n)
    temp=src.copy(); label=np.zeros(n,dtype=int); atype=np.array(['normal']*n,dtype=object)
    for a,b,typ in common_events:
        shift=int(rng.integers(-8,9)); aa=max(0,a+shift); bb=min(n,b+shift)
        if 'spike' in typ:
            idx=rng.choice(np.arange(aa,bb), size=max(6,(bb-aa)//4), replace=False)
            temp[idx]+=rng.choice([-1,1],len(idx))*rng.uniform(2.0,4.5,len(idx)); label[idx]=1; atype[idx]=typ
        elif 'drift' in typ:
            idx=np.arange(aa,bb); temp[idx]+=np.linspace(0.2,1.6,len(idx)); label[idx]=1; atype[idx]=typ
        else:
            idx=np.arange(aa,bb); temp[idx]=temp[aa]; label[idx]=1; atype[idx]=typ
    # local node-specific anomalies
    idx=rng.choice(np.setdiff1d(np.arange(n), np.where(label==1)[0]), size=18, replace=False)
    temp[idx]+=rng.choice([-1,1],len(idx))*rng.uniform(1.8,4.0,len(idx)); label[idx]=1; atype[idx]='local_spike'
    df=pd.DataFrame({'time_min':t,'timestamp':pd.date_range('2025-01-08 08:00:00',periods=n,freq='min').astype(str),'node_id':f'node_{node:02d}','temp_c':np.round(temp,4),'source_signal':np.round(src,4),'anomaly_label':label,'anomaly_type':atype,'severity':np.where(label,'medium','none'),'lat':38.73695+node*0.001,'lon':-9.1428-node*0.001})
    parts.append(df)
pd.concat(parts,ignore_index=True).to_csv(OUT/'appendixB_scenario7_multinode_correlated_labeled.csv',index=False)
print('Generated local Appendix B datasets:', [p.name for p in OUT.glob('appendixB_scenario*_labeled.csv')])
