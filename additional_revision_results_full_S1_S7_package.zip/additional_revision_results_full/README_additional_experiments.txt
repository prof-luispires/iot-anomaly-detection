Additional experimental package for major revision

Scope:
1. Isolation Forest and One-Class SVM baselines over S1-S7.
2. Repeated runs with mean, standard deviation and 95% confidence interval.
3. Compact sensitivity analysis for filter thresholds and RL-like parameters.
4. MARL scalability proxy over Scenario 7 with 4, 8 and 12 agents/sensors.

Important note:
S1-S4 were the local manuscript datasets. S5-S7 were locally regenerated from the documented Appendix B scenario definitions because direct raw download from Google Drive into the execution runtime was unavailable. The script is prepared to use the original CSV files when placed in the same folder.

Key output files:
- benchmark_if_ocsvm_summary.csv
- benchmark_if_ocsvm_detailed.csv
- sensitivity_analysis_results.csv
- marl_scalability_summary.csv
- marl_scalability_detailed.csv

Recommended use in manuscript:
- Use benchmark_if_ocsvm_summary.csv for the new baseline-comparison table.
- Use sensitivity_analysis_results.csv to select a compact sensitivity table or heatmap.
- Use marl_scalability_summary.csv to support the response to Reviewer 1, Comment 2.
